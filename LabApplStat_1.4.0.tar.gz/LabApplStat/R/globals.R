#' @importFrom graphics text
#' @importFrom stats as.formula formula model.frame model.matrix model.response pf pt qt quantile r2dtable rmultinom rt terms
#' @importFrom emmeans emmeans
#' @importFrom ggplot2 aes arrow unit geom_blank geom_label coord_fixed 

{}
